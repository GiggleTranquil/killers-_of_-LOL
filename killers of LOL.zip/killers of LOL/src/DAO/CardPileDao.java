package DAO;
import card.Card;

public interface CardPileDao<T> {
	public Card drawCard();
	public void addCard(Card card);
	public void refreshPile(T discardPile);
	public boolean isEmpty();
	public void initializePile();
	public void addAll(T cardList);
}
