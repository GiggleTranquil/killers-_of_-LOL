package card;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.TextField;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class Card extends JLabel implements MouseListener {

	/**游戏的主界面*/
	private GameJFrame gameJFrame;

	private String name;

	private String introduce;

	private JTextArea cardIntroduce;

	private CardColor color;

	private CardRank rank;

	private CardType type;

	/**牌的效果*/
	private PlayerState effect = null;
	
	/**牌显示正面or反面*/
	private boolean up;

	/**牌是否可以被点击*/
	private boolean canClick = false;

	/**当前的状态：当前的牌是否已经被点击
	   如果未被点击，点击则弹起
	   如果已被点击，点击则落下*/
	private boolean clicked = false;
	
	/**此时能否与多张牌同时点击*/
	private boolean multipleClicks = false;

	public Card( String name, CardColor color, CardRank rank, CardType type, PlayerState effect , String introduce,GameJFrame m, boolean up) {
		this.name = name;
		this.color = color;
		this.rank = rank;
		this.type = type;
		this.effect = effect;
		this.introduce = introduce;
		
		//GUI部分
		this.gameJFrame = m;
		this.up = up;

		// 判断当前的牌显示正面or反面
		if (this.up) {
			// 显示正面
			turnFront();
		} else {
			// 显示反面
			turnRear();

		}

		// 设置牌的宽高
		this.setSize(98, 138);
		// 把牌显示出来
		this.setVisible(true);
		// 添加监听
		this.addMouseListener(this);
	}

	public Card(GameJFrame gameJFrame, String name, boolean up) {
		this.gameJFrame = gameJFrame;
		this.name = name;
		this.up = up;
	}

	public void turnFront() {

		// 花色设置
		JLabel cardColorLabel = null;
		if (this.color == CardColor.CLUB) {
			cardColorLabel = new JLabel(new ImageIcon(
					"src/images/color_meihua.png"));
		} else if (this.color == CardColor.DIAMOND) {
			cardColorLabel = new JLabel(new ImageIcon(
					"src/images/color_fangkuai.png"));
		} else if (this.color == CardColor.HEART) {
			cardColorLabel = new JLabel(new ImageIcon(
					"src/images/color_hongxin.png"));
		} else if (this.color == CardColor.SPADE) {
			cardColorLabel = new JLabel(new ImageIcon(
					"src/images/color_heitao.png"));
		} else if (this.color == CardColor.NONE) {
			cardColorLabel = new JLabel();
		}
		cardColorLabel.setSize(22, 22);
		cardColorLabel.setBounds(5, 23, 22, 22);
		cardColorLabel.setVisible(true);
		this.add(cardColorLabel);
		this.setComponentZOrder(cardColorLabel, 0);
		this.repaint();

		// 点数设置
		JTextField rank = new JTextField(this.rank.getR());
		//字体颜色
		if ((this.color == CardColor.CLUB) || this.color == CardColor.SPADE) {
			rank.setForeground(Color.black);
		} else {
			rank.setForeground(Color.red);
		}
		Font font = new Font("黑体", Font.PLAIN, 15);
		rank.setFont(font);
		rank.setSize(20, 20);
		rank.setBounds(10, 9, 15, 15);
		rank.setEditable(false);
		rank.setOpaque(false);
		rank.setBorder(null);
		this.add(rank);
		this.setComponentZOrder(rank, 0);
		this.repaint();

		// 修改成员变量
		this.up = true;
	}

	public void turnRear() {
		// 给牌设置反面
		this.removeAll();
		this.setIcon(new ImageIcon("src/images/bg_card(1).jpg"));
		this.repaint();
		gameJFrame.repaint();
		// 修改成员变量
		this.up = false;
	}
	
	/**看具体的牌*/
	public void effect(Player player) {}
	
	public void beEquiped() {}

	/**鼠标方法 */
	@Override
	public void mouseClicked(MouseEvent e) {
		//点击 -- 升起 or 降落
		if (canClick) {
			Point from = this.getLocation();
			int step;
			if (clicked) {
				//已经被点击：下降, 而且原本选中的角色不变成未选中状态
				step = 20;
				for(Player player : gameJFrame.getPlayersArr()) {
					if(player.getSelectedRole().isSelected()) {
						player.getSelectedRole().changeIsSelected();
						//player.getSelectedRole().setSelected(false);
					}
				}
			} else {
				//未被点击：上升，且其他上升的牌下降
				step = -20;
				if(!multipleClicks) {
					for (Card card : gameJFrame.playerList.get(0)) {
						if ((card != this) && (card.isClicked())) {
							card.setClicked(false);
							card.setLocation(card.getX(), card.getY() + 20);
						}
					}
				}
			}
			clicked = !clicked;
			Point to = new Point(from.x, from.y + step);
			this.setLocation(to);
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(this.up) {
			cardIntroduce = new JTextArea(" " + name + "：\n " + this.introduce);
			cardIntroduce.setSize(180,40);
			cardIntroduce.setEditable(false);
			cardIntroduce.setBounds(this.getX(), this.getY()+150, 180, 40);
		    gameJFrame.getContainer().add(cardIntroduce);
		    gameJFrame.getContainer().setComponentZOrder(cardIntroduce, 0);
		    gameJFrame.repaint();
		}
	    
		

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		if(this.up) {
			if(cardIntroduce != null) {
				gameJFrame.remove(cardIntroduce);
				gameJFrame.repaint();
			}
		}
	}
	public GameJFrame getGameJFrame() {
		return gameJFrame;
	}

	public void setGameJFrame(GameJFrame gameJFrame) {
		this.gameJFrame = gameJFrame;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isUp() {
		return up;
	}

	public void setUp(boolean up) {
		this.up = up;
	}

	public boolean isCanClick() {
		return canClick;
	}

	public void setCanClick(boolean canClick) {
		this.canClick = canClick;
	}

	public boolean isClicked() {
		return clicked;
	}

	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}

	public CardColor getColor() {
		return color;
	}

	public void setColor(CardColor color) {
		this.color = color;
	}

	public CardRank getRank() {
		return rank;
	}

	public void setRank(CardRank rank) {
		this.rank = rank;
	}

	public CardType getType() {
		return type;
	}

	public void setType(CardType type) {
		this.type = type;
	}

	public PlayerState getEffect() {
		return effect;
	}

	public void setEffect(PlayerState effect) {
		this.effect = effect;
	}

	public boolean isMultipleClicks() {
		return multipleClicks;
	}

	public void setMultipleClicks(boolean multipleClicks) {
		this.multipleClicks = multipleClicks;
	}
}
