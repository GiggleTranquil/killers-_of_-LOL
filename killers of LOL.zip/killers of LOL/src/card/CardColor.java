package card;

public enum CardColor {
	HEART("♥", 1), SPADE("♠", 2), DIAMOND("♦", 3), CLUB("♣", 4), NONE(" ", 5);// 红桃，黑桃，方块，梅花,无花色

	public String name;
	public int value;

	CardColor(String s, int i) {
		this.name = s;
		this.value = i;
	}

	public String getName() {
		return name;
	}

	public int getValue() {
		return value;
	}
}