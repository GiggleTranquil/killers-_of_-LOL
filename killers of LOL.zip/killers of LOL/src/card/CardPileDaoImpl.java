package card;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import DAO.CardPileDao;
import game.GameJFrame;
import realCard.*;

public class CardPileDaoImpl implements CardPileDao {
	static ArrayList<Card> cardPile = new ArrayList<>();
	GameJFrame gameJFrame;
	
	public CardPileDaoImpl(GameJFrame gameJFrame) {//牌堆用构造方法
		this.gameJFrame = gameJFrame;
		initializePile();
		Collections.shuffle(cardPile);
	}
	
	public CardPileDaoImpl() {};//弃牌堆所用构造方法
	
	public Card drawCard() {
		Card card = cardPile.get(0);
		cardPile.remove(0);
		return card;
	}
	
	public void addCard(Card card) {
		cardPile.add(card);
	}
	
	public boolean isEmpty() {
		if (cardPile.size() == 0)
			return true;
		return false;
	}
	
	public void refreshPile(Object discardPile) {
		if(discardPile.getClass().equals(cardPile.getClass()))
		{
			ArrayList<Card> pile = (ArrayList<Card>)discardPile;
			cardPile.addAll(pile);
		}
	}
	
	public ArrayList<Card> getList() {
		return cardPile;
	}
	
	public void initializePile() {
		File file = new File("src/InitializedCards.txt");
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				String temp[] = tempString.split(" ");
				switch (temp[0]) {
				case "多兰剑":
					cardPile.add(
							new CardDuoLanJian(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
					break;
				case "多兰盾":
					cardPile.add(
							new CardDuoLanDun(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
					break;
				case "血瓶":
					cardPile.add(
							new CardXuePing(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
					break;
				case"水晶箭":
				cardPile.add(
						new CardShuiJingJian(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
				case"救赎":
					cardPile.add(
							new CardJiuShu(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
					break;
				case"怨夺":
					cardPile.add(
							new CardYuanDuo(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
					break;
				case"羊刀":
					cardPile.add(
							new CardYangDao(CardColor.valueOf(temp[1]), CardRank.valueOf(temp[2]), gameJFrame, false));
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}

	public void addAll(Object cardList) {
		if(cardList.getClass().equals(cardPile.getClass()))
		{
			ArrayList<Card> pile = (ArrayList<Card>)cardList;
			cardPile.addAll(pile);
		}
		
	}
}
