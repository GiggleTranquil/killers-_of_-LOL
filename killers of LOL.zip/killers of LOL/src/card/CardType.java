package card;

public enum CardType {
	BASE("基本牌", 1), TIP("锦囊牌", 2),WEAPON("武器牌",3),ARMOR("防具牌", 4),ATTACK_HORSE("进攻马", 5),DEFENCE_HORSE("防御马", 6);

	public String name;
	public int value;

	CardType(String s, int i) {
		this.name = s;
		this.value = i;
	}

	public String getS() {
		return name;
	}

	public int getI() {
		return value;
	}

}
