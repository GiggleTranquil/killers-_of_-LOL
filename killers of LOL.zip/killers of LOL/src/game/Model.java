package game;

import card.Card;
import player.Player;
import realCard.CardDuoLanJian;
import realCard.CardDuoLanDun;

public class Model {
	/**会受到伤害的类型*/
	Card[] beHurtType = new Card[2];
	/**躲避伤害类型*/
	Card[] dodgeHurtType = new Card[2];
	
	/**要扣血的情况*/
	public static boolean beHurt(Player activeSide,Card sendCard, Player passiveSide,Card copeCard) {
		if(sendCard.getClass() == CardDuoLanJian.class) {
			if(copeCard == null) {
				return true;
			}
			else if(copeCard.getClass() ==  CardDuoLanDun.class) {
				return false;
			}
		}
		return false;
	}

}
