package game;

import java.awt.Point;

import card.Card;

public class MoveCartoon implements Runnable{
	private Card card;
	private Point point;
	
	public MoveCartoon(Card aCard,Point aPoint) {
		card = aCard;
		point = aPoint;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Common.move(card, card.getLocation(), point);
		card.repaint();
	}

}
