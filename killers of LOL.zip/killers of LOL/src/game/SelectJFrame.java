package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class SelectJFrame extends JFrame {
    private Common common = new Common(this);
    private Container container = null;
    public static List<String> selectRole=new ArrayList<>();
    public static List<String> roleList=new ArrayList<>();
    private JButton backspace=new JButton("撤销");
    private JButton sure=new JButton("进入游戏");
    public SelectJFrame()
    {
        //设置左上角图标
        setIconImage(Toolkit.getDefaultToolkit().getImage("src/images/logo.png"));
        addRole();
        selectRole();
        this.setVisible(true);
    }
    public void addRole()
    {
        roleList.add("nuoshou");
        roleList.add("xixuegui");
        roleList.add("dema");
        roleList.add("jianmo");
        roleList.add("kapai");
        roleList.add("aolafu");
    }
    public void selectRole()
    {
        this.setTitle("英雄联盟杀");
        // 设置大小
        this.setSize(1024, 768);
        // 设置关闭模式
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 设置窗口无法进行调节
        this.setResizable(false);
        // 界面居中
        this.setLocationRelativeTo(null);
        // 获取界面中的隐藏容器，以后直接用无需再次调用方法获取了
        container = this.getContentPane();
        // 取消内部默认的居中放置
        container.setLayout(null);
        JLabel background = new JLabel(new ImageIcon("src/images/background.jpg"));
        background.setBounds(0, 0, 1024, 768);
        background.setOpaque(false);
        container.add(background);
        JLabel label=new JLabel("请选择你的英雄");
        label.setFont(new Font("楷体",Font.PLAIN,20));
        label.setForeground(new Color(255,255,255));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(new Color(255,255,255,125));
        label.setBounds(50,50,100,40);
        container.add(label);
        container.setComponentZOrder(label,0);
        JLabel bak=new JLabel(new ImageIcon("src/images/bak.jpg"));
        bak.setBounds(50,100,1024-150,368);
        container.add(bak);
        container.setComponentZOrder(bak,0);
        JLabel bgControl=new JLabel(new ImageIcon("src/images/background_Select.jpg"));
        bgControl.setBounds(50,475,170,190);
        container.add(bgControl);
        container.setComponentZOrder(bgControl,0);
        JLabel bgControl1=new JLabel(new ImageIcon("src/images/background_Select.jpg"));
        bgControl1.setBounds(450,475,170,190);
        container.add(bgControl1);
        container.setComponentZOrder(bgControl1,0);
        backspace.setEnabled(false);
        backspace.setBounds(750,480,100,50);
        container.add(backspace);
        container.setComponentZOrder(backspace,0);
        sure.setEnabled(false);
        sure.setBounds(750,560,100,50);
        container.add(sure);
        container.setComponentZOrder(sure,0);
        backspace.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectRole.remove(selectRole.size()-1);
                if(selectRole.size()==0)
                {
                    JLabel bgControl=new JLabel(new ImageIcon("src/images/background_Select.jpg"));
                    bgControl.setBounds(50,475,170,190);
                    container.add(bgControl);
                    container.setComponentZOrder(bgControl,0);
                    repaint();
                    backspace.setEnabled(false);
                }
                else if(selectRole.size()==1)
                {
                    JLabel bgControl1=new JLabel(new ImageIcon("src/images/background_Select.jpg"));
                    bgControl1.setBounds(450,475,170,190);
                    container.add(bgControl1);
                    container.setComponentZOrder(bgControl1,0);
                    repaint();
                    sure.setEnabled(false);
                }
            }
        });
        sure.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new GameJFrame();
            }
        });
        int x=60,y=110;
        for (String s : roleList) {
            JLabel role=new JLabel(new ImageIcon(("src/images/P_"+s+".jpg")));
            role.setBounds(x, y,163,175);
            container.add(role);
            container.setComponentZOrder(role,0);
            role.addMouseListener(new MyMouseListener(s));
            x+=170;
            if(x>1024-150)
            {
                y+=180;
                x=60;
            }
        }
    }
    class MyMouseListener extends MouseAdapter
    {
        String s=null;

        public MyMouseListener(String s) {
            this.s = s;
        }

        public MyMouseListener() {
        }

        @Override
        public void mousePressed(MouseEvent e) {
            if(selectRole.size()==0)
            {
                System.out.println(s);
                JLabel role1=new JLabel(new ImageIcon(("src/images/P_"+s+".jpg")));
                role1.setBounds(55,480,163,175);
                container.add(role1);
                container.setComponentZOrder(role1,0);
                selectRole.add(s);
                System.out.println(selectRole.size());
                backspace.setEnabled(true);
                repaint();
            }
            else if(selectRole.size()==1)
            {
                System.out.println(s);
                JLabel role2=new JLabel(new ImageIcon(("src/images/P_"+s+".jpg")));
                role2.setBounds(455,480,163,175);
                container.add(role2);
                container.setComponentZOrder(role2,0);
                selectRole.add(s);
                System.out.println(selectRole.size());
                sure.setEnabled(true);
                repaint();
            }
        }
    }

    public JButton getBackspace() {
        return backspace;
    }

    public void setBackspace(JButton backspace) {
        this.backspace = backspace;
    }

    public JButton getSure() {
        return sure;
    }

    public void setSure(JButton sure) {
        this.sure = sure;
    }

    public Common getCommon() {
        return common;
    }

    public void setCommon(Common common) {
        this.common = common;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

}