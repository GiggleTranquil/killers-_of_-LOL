package main;

import game.SelectJFrame;

public class APP {

	public static void main(String[] args) {
		new SelectJFrame();
	}

}
