package player;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import game.GameJFrame;

public class HP extends JLabel{
	private int maximumHP;
	private int actualHP;
	GameJFrame gameJFrame;
	
	public HP(int maximumHP, int actualHP, GameJFrame gameJFrame) {
		this.maximumHP = maximumHP;
		this.actualHP = actualHP;
		this.gameJFrame = gameJFrame;
		
		//设置整个生命条的大小
		this.setSize(22, 22*maximumHP);
		//显示生命条
		this.setVisible(true);
	}
	
	public void rePaintHP() {
		int i,j;
		for(i = 0; i < maximumHP - actualHP; i++) {
			JLabel blood = new JLabel(new ImageIcon("src/images/hp2.png"));
			blood.setSize(22,20);
			blood.setBounds(0, 20*i, 22, 20);
			blood.setVisible(true);
			this.add(blood);
			this.setComponentZOrder(blood, 0);
			this.repaint();
		}
		for(j = i; j < maximumHP; j++) {
			JLabel blood = new JLabel(new ImageIcon("src/images/hp.png"));
			blood.setSize(22,20);
			blood.setBounds(0, 20*j, 22, 20);
			blood.setVisible(true);
			this.add(blood);
			this.setComponentZOrder(blood, 0);
			this.repaint();
		}
	}

	public int getMaximumHP() {
		return maximumHP;
	}

	public void setMaximumHP(int maximumHP) {
		this.maximumHP = maximumHP;
	}

	public int getActualHP() {
		return actualHP;
	}

	public void setActualHP(int actualHP) {
		this.actualHP = actualHP;
	}

	public GameJFrame getGameJFrame() {
		return gameJFrame;
	}

	public void setGameJFrame(GameJFrame gameJFrame) {
		this.gameJFrame = gameJFrame;
	}
	
	


}
