package player;

import java.util.ArrayList;

import card.Card;
import game.GameJFrame;
import role.Role;

public class Player {
	private HP HP;
	private ArrayList<Card> handsCard = new ArrayList<>();
	private ArrayList<Card> judgeCard = new ArrayList<>();
	private Role selectedRole;
	private PlayerState state =  null;
	private int serialNumber;
	private Card[] equipment = new Card[4];
	
	private GameJFrame gameJFrame;
	/**是否发出卡牌杀*/
	private boolean sendCardShaFlag = false;
	/**是否是我的回合-->为了确认可不可以发动技能*/
	private boolean myRound = true;
	/**是否能得牌-->为了确认我能不能拿牌*/
	private boolean canGetCard = true;

	public HP getHP() {
		return HP;
	}

	public void setHP(HP hP) {
		HP = hP;
	}

	public ArrayList<Card> getHandsCard() {
		return handsCard;
	}

	public void setHandsCard(ArrayList<Card> handsCard) {
		this.handsCard = handsCard;
	}

	public ArrayList<Card> getJudgeCard() {
		return judgeCard;
	}

	public void setJudgeCard(ArrayList<Card> judgeCard) {
		this.judgeCard = judgeCard;
	}

	public Role getSelectedRole() {
		return selectedRole;
	}

	public void setSelectedRole(Role selectedRole) {
		this.selectedRole = selectedRole;
	}
	public PlayerState getState() {
		return state;
	}

	public void setState(PlayerState state) {
		this.state = state;
	}
	
	public boolean isSendCardShaFlag() {
		return sendCardShaFlag;
	}

	public void setSendCardShaFlag(boolean sendCardShaFlag) {
		this.sendCardShaFlag = sendCardShaFlag;
	}

	public boolean isMyRound() {
		return myRound;
	}

	public void setMyRound(boolean myRound) {
		this.myRound = myRound;
	}
	
	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public GameJFrame getGameJFrame() {
		return gameJFrame;
	}

	public void setGameJFrame(GameJFrame gameJFrame) {
		this.gameJFrame = gameJFrame;
	}
	public boolean isCanGetCard() {
		return canGetCard;
	}

	public void setCanGetCard(boolean canGetCard) {
		this.canGetCard = canGetCard;
	}
	
	public Card[] getEquipment() {
		return equipment;
	}

	public void setEquipment(Card[] equipment) {
		this.equipment = equipment;
	}

	/**构造方法*/
	public Player(ArrayList<Card> handsCard, ArrayList<Card> judgeCard, Role selectedRole,  GameJFrame gameJFrame, int serialNumber) {
		super();
		this.selectedRole = selectedRole;
		this.handsCard = handsCard;
		this.judgeCard = judgeCard;
		this.HP = new HP(selectedRole.getMaximumHP(),selectedRole.getMaximumHP(),gameJFrame);
		this.serialNumber = serialNumber;
		for(int i = 0; i < 4; i++) {
			this.equipment[i] = null;
		}
	}
	
	/**玩家操作*/
	public void reduceHP() {
		if(this.HP.getActualHP() != 0) {
			int newActualHP = this.HP.getActualHP() - 1;
			this.HP.setActualHP(newActualHP);
		}
	}
	
	/**被使用桃*/
	public void recoverHP() {
		int newActualHP = this.HP.getActualHP() + 1;
		this.HP.setActualHP(newActualHP);
	}
	
	/**自身的的一个刷新*/
	public void reflesh() {
		this.sendCardShaFlag = false;
	}


}

