package player;

public enum PlayerState {
	BEHURT, //被伤害，但还未受伤
	BEHURTED, //被伤害后了：即已经受伤
	GET_TREATED, //获得治疗
	EQUIPPED, //被装备的:可能要改
	
	PUSH_THE_LIMIT,//解除限制
	NONE;

}
