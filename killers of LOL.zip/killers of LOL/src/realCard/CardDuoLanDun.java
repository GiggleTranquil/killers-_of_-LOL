package realCard;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.PlayerState;

public class CardDuoLanDun extends Card{

	static String cardIntroduce = "抵挡敌方的伤害";
	
	public CardDuoLanDun(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("闪", color, rank, CardType.BASE, PlayerState.NONE,cardIntroduce, m, up);
		// TODO Auto-generated constructor stub
	}
	
	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/kduolandun.png"));
		super.turnFront();
	}

}
