package realCard;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.PlayerState;

public class CardDuoLanJian extends Card {

	static String cardIntroduce = "对指定的一名敌人造成伤害";
	public CardDuoLanJian(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("多兰剑", color, rank, CardType.BASE, PlayerState.BEHURT, cardIntroduce ,m, up);
		// TODO Auto-generated constructor stub
	}

	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/kduolanjian.png"));
		super.turnFront();
	}

}
