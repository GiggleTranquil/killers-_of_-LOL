package realCard;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class CardJiuShu extends Card{
	
	static String cardIntroduce = "对棋盘内所有角色使用，体力加1";
	public CardJiuShu(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("救赎", color, rank, CardType.TIP, PlayerState.GET_TREATED, cardIntroduce ,m, up);
		// TODO Auto-generated constructor stub
	}

	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/J_jiushu.png"));
		super.turnFront();
	}
	
	@Override
	public void effect(Player player) {
		//所有人都生命+1
		for (Player thePlayer : this.getGameJFrame().getPlayersArr()) {
			if(thePlayer.getHP().getActualHP() != thePlayer.getHP().getMaximumHP()) {
				thePlayer.recoverHP();
				thePlayer.getHP().rePaintHP();
			}
		}
	}

}
