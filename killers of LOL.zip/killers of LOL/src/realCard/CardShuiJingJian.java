package realCard;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class CardShuiJingJian extends Card{
	
	static String cardIntroduce = "除你之外的所有人出一张多兰盾，否则受到伤害";
	public CardShuiJingJian(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("水晶箭", color, rank, CardType.TIP, PlayerState.BEHURT, cardIntroduce ,m, up);
		// TODO Auto-generated constructor stub
	}

	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/J_shuijingjian.png"));
		super.turnFront();
	}
	
	@Override
	public void effect(Player player) {
		//除我之外所有人进入受伤状态
		for (Player otherPlayer : this.getGameJFrame().getPlayersArr()) {
			if(otherPlayer != player) {
				otherPlayer.setState(PlayerState.BEHURT);
			}
		}
	}

}
