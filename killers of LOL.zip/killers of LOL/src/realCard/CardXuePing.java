package realCard;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class CardXuePing extends Card {

	static String cardIntroduce = "恢复1滴体力值";
	
	public CardXuePing(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("桃", color, rank, CardType.BASE,PlayerState.GET_TREATED, cardIntroduce,m, up);
	}
	
	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/kxueping.png"));
		super.turnFront();
	}
	
	@Override
	public void effect(Player player) {
		//选中的玩家生命+1
		if(player.getHP().getActualHP() != player.getHP().getMaximumHP()) {
			int newActualHP = player.getHP().getActualHP() + 1;
			player.getHP().setActualHP(newActualHP);
			player.getHP().rePaintHP();
		}
	}

}
