package realCard;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class CardYangDao extends Card{

    static String cardIntroduce = "装备后，一回合内可无限出多兰剑";
    JLabel background;
    JLabel armsImage;
    
	
	public CardYangDao(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("羊刀", color, rank, CardType.WEAPON, PlayerState.PUSH_THE_LIMIT, cardIntroduce, m, up);
	}
	
	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/eq_yangdao.png"));
		super.turnFront();
	}
	
	@Override
	public void beEquiped() {
		
		background = new JLabel(new ImageIcon("src/images/bg_equip.png"));
		background.setBounds(65, 515, 170, 40);
		background.setVisible(true);
		armsImage = new JLabel(new ImageIcon("src/images/equiped_yangdao.png"));
		armsImage.setBounds(5, 0, 50, 40);
		armsImage.setVisible(true);
		JLabel nameLabel = new JLabel(this.getName());
		nameLabel.setBounds(55, 0, 60, 40);
		nameLabel.setVisible(true);
		JLabel colorLabel = new JLabel(this.getColor().getName());
		colorLabel.setBounds(115, 0, 20, 40);
		colorLabel.setVisible(true);
		JLabel rankLabel = new JLabel(this.getRank().getR());
		rankLabel.setBounds(135, 0, 15, 40);
		rankLabel.setVisible(true);
		background.add(armsImage);
		background.add(nameLabel);
		background.add(colorLabel);
		background.add(rankLabel);
		background.repaint();
		this.getGameJFrame().getContainer().add(background);
		this.getGameJFrame().getContainer().setComponentZOrder(background, 0);
		this.getGameJFrame().getContainer().repaint();
	}
	
	@Override
	public void effect(Player player) {
		player.setSendCardShaFlag(false);
	}

}
