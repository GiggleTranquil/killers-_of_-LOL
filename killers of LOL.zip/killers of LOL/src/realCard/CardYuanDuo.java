package realCard;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.ImageIcon;

import card.Card;
import card.CardColor;
import card.CardRank;
import card.CardType;
import game.Common;
import game.GameJFrame;
import player.Player;
import player.PlayerState;

public class CardYuanDuo extends Card {
	static String cardIntroduce = "充满怨恨，掠夺两张手牌";

	public CardYuanDuo(CardColor color, CardRank rank, GameJFrame m, boolean up) {
		super("怨夺", color, rank, CardType.TIP, PlayerState.NONE, cardIntroduce, m, up);
		// TODO Auto-generated constructor stub
	}

	public void turnFront() {
		this.setIcon(new ImageIcon("src/images/J_yuanduo.png"));
		super.turnFront();
	}

	@Override
	public void effect(Player player) {
		// 立即获得两张牌
		ArrayList<Card> addCardList = new ArrayList<>();

		if (this.getGameJFrame().getCardList().size() < 2) {
			int remain = this.getGameJFrame().getCardList().size();
			for (int i = 0; i < this.getGameJFrame().getCardList().size(); i++) {
				Card addCard = this.getGameJFrame().getCardList().get(i);
				addCard.setCanClick(true);
				addCardList.add(addCard);
			}
			deckUpdate(this.getGameJFrame().getCardList(), this.getGameJFrame().getFoldPile());
			System.out.println("更新完的牌堆的长度为：" + this.getGameJFrame().getCardList().size());
			for (int i = 0; i < 2 - remain; i++) {
				Card addCard = this.getGameJFrame().getCardList().get(i);
				addCard.setCanClick(true);
				addCardList.add(addCard);
			}
			for (int i = 0; i < 2; i++) {
				Card addCard = addCardList.get(i);
				Point to = null;
				if (player.getHandsCard().size() != 0) {
					to = new Point(this.getGameJFrame().playerList.get(0).get(this.getGameJFrame().playerList.get(0).size() - 1).getX() + i * 90, 530);
				} else {
					to = new Point(110, 530);
				}

				Common.moveCard(addCard, to);
				addCard.turnFront();
			}
		} else {
			for (int i = 0; i < 2; i++) {
				Card addCard = this.getGameJFrame().getCardList().get(i);
				addCard.setCanClick(true);
				Point to = null;
				if (player.getHandsCard().size() != 0) {
					to = new Point(this.getGameJFrame().playerList.get(0).get(this.getGameJFrame().playerList.get(0).size() - 1).getX() + i * 90, 530);
				} else {
					to = new Point(110, 530);
				}
				Common.moveCard(addCard, to);
				addCard.turnFront();
				addCardList.add(addCard);
			}
		}
		this.getGameJFrame().getCardList().removeAll(addCardList);
		player.getHandsCard().addAll(addCardList);

	}

	/** 牌堆更新 */
	public void deckUpdate(ArrayList<Card> deck, ArrayList<Card> foldPile) {
		Collections.shuffle(foldPile);
		for (Card card : foldPile) {
			card.setVisible(true);
			card.turnRear();
			card.setCanClick(false);
			card.setClicked(false);
			this.getGameJFrame().getContainer().setComponentZOrder(card, 0);
			Common.moveCard(card, new Point(30, 200));
			deck.add(card);
		}
		foldPile.clear();
	}

}
