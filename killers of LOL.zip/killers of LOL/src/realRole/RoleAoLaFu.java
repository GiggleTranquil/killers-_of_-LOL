package realRole;

import javax.swing.ImageIcon;

import game.GameJFrame;
import realSkill.SkillKuangBao;
import role.Role;


public class RoleAoLaFu extends Role{
	
	public RoleAoLaFu(GameJFrame gameJFrame) {
		super("奥拉夫", new SkillKuangBao(gameJFrame), 3, gameJFrame);
	}

	public void paintRole(){
        this.setIcon(new ImageIcon("src/images/P_aolafu.jpg"));
    }
}
