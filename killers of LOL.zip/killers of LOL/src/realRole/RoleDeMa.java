package realRole;

import javax.swing.ImageIcon;

import game.GameJFrame;
import realSkill.SkillPoFu;
import role.Role;

public class RoleDeMa extends Role {

	final boolean sendShaFlag = true;

	public RoleDeMa(GameJFrame gameJFrame) {
		super("德玛", new SkillPoFu(gameJFrame), 4, gameJFrame);
	}

	public void paintRole() {
		this.setIcon(new ImageIcon("src/images/P_dema.jpg"));
	}

}
