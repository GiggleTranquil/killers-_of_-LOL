package realRole;

import game.GameJFrame;
import role.Role;
import skill.Skill;

import javax.swing.*;

public class RoleJianMo extends Role {
    public RoleJianMo(GameJFrame gameJFrame) {
        super("剑魔",new Skill("绝境", null, "失去最后一张手牌后可以再摸一张"), 4, gameJFrame);
    }
    public void paintRole(){
        this.setIcon(new ImageIcon("src/images/P_jianmo.jpg"));
    }
}

