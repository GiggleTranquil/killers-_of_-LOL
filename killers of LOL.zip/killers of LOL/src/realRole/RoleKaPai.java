package realRole;

import game.GameJFrame;
import role.Role;
import skill.Skill;

import javax.swing.*;

public class RoleKaPai extends Role {
    public RoleKaPai(GameJFrame gameJFrame) {
        super("卡牌",new Skill("积攒", null, "可以跳过弃牌阶段"), 3, gameJFrame);
    }
    public void paintRole(){
        this.setIcon(new ImageIcon("src/images/P_kapai.jpg"));
    }
}
