package realRole;

import javax.swing.ImageIcon;

import game.GameJFrame;
import realSkill.SkillWQTS;
import role.Role;

public class RoleNuoShou extends Role{

	public RoleNuoShou(GameJFrame gameJFrame) {
		super("诺手", new SkillWQTS(gameJFrame), 4, gameJFrame);
	}

	/**显示gui*/
	public void paintRole(){
		this.setIcon(new ImageIcon("src/images/P_nuoshou.jpg"));
	}
}
