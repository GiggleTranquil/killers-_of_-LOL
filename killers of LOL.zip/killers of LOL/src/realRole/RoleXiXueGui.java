package realRole;

import game.GameJFrame;
import realSkill.SkillZhiHuan;
import realSkill.SkillZhiHuan;
import role.Role;
import javax.swing.*;

public class RoleXiXueGui extends Role {

	public RoleXiXueGui(GameJFrame gameJFrame) {
		super("吸血鬼", new SkillZhiHuan(gameJFrame), 4, gameJFrame);
		// TODO Auto-generated constructor stub
	}

	public void paintRole() {
		this.setIcon(new ImageIcon("src/images/P_XiXueGui.jpg"));
	}
}
