package realSkill;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;

import card.Card;
import game.Common;
import game.GameJFrame;
import player.Player;
import skill.Skill;
import skill.SkillType;

public class SkillJiLei extends Skill {

    static String skillIntroduce = "可以跳过弃牌阶段";
    GameJFrame gameJFrame;

    public SkillJiLei(GameJFrame gameJFrame) {
        super("积累", SkillType.WHEN_HURT, skillIntroduce);
        this.gameJFrame = gameJFrame;
        // TODO Auto-generated constructor stub
    }

    public void effect() {
        /* 1.找到角色所在的位置 */
        int locate = -1;
        for (Player player : gameJFrame.getPlayersArr()) {
            if (player.getSelectedRole().getName().equals("卡牌")) {
                locate = player.getSerialNumber();
            }
        }

        /*2.解除出杀限制：即一直让角色的出杀标志为false*/
        if(gameJFrame.getPlayersArr().get(locate).isSendCardShaFlag()) {
            gameJFrame.getPlayersArr().get(locate).setSendCardShaFlag(false);
            gameJFrame.getRecordArea().append("奥拉夫发动了技能（狂暴），其出杀限制重置\n");
        }
    }
}
