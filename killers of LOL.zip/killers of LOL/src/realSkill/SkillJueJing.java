package realSkill;

import game.GameJFrame;
import skill.Skill;
import skill.SkillType;

public class SkillJueJing extends Skill{

	static String skillIntroduce = "失去最后一张手牌后可以再摸一张";
	GameJFrame gameJFrame;
	
	public SkillJueJing(GameJFrame gameJFrame) {
		super("绝境", SkillType.PUSH_THE_LIMITS, skillIntroduce);
		this.gameJFrame = gameJFrame;
		// TODO Auto-generated constructor stub
	}
	

}
