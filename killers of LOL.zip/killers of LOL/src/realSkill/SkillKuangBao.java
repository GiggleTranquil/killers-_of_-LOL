package realSkill;


import game.GameJFrame;
import player.Player;
import skill.Skill;
import skill.SkillType;

public class SkillKuangBao extends Skill{

	static String skillIntroduce = "使用杀无次数限制";
	GameJFrame gameJFrame;
	
	public SkillKuangBao(GameJFrame gameJFrame) {
		super("狂暴", SkillType.PUSH_THE_LIMITS, skillIntroduce);
		this.gameJFrame = gameJFrame;
		// TODO Auto-generated constructor stub
	}
	
	public void effect() {
		/*1.找到张飞所在的位置*/
		int locate = -1;
		System.out.println(this.gameJFrame.getPlayersArr());
		for (Player player : gameJFrame.getPlayersArr()) {
			if(player.getSelectedRole().getName().equals("奥拉夫")) {
				locate = player.getSerialNumber();
			}
		}
		
		/*2.解除出杀限制：即一直让角色的出杀标志为false*/
		if(gameJFrame.getPlayersArr().get(locate).isSendCardShaFlag()) {
			gameJFrame.getPlayersArr().get(locate).setSendCardShaFlag(false);
			gameJFrame.getRecordArea().append("奥拉夫发动了技能（狂暴），其出杀限制重置\n");
		}
		
	}

}
