package realSkill;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;

import card.Card;
import game.Common;
import game.GameJFrame;
import player.Player;
import skill.Skill;
import skill.SkillType;

public class SkillPoFu extends Skill{
	static String skillIntroduce = "出牌阶段可以主动失去一点体力摸两张牌";
	GameJFrame gameJFrame;
	
	public SkillPoFu(GameJFrame gameJFrame) {
		super("破釜", SkillType.WHEN_BUTTON_CLICKED, skillIntroduce);
		this.gameJFrame = gameJFrame;
		// TODO Auto-generated constructor stub
	}
	
	public void effect() {
		/*1.找到德玛位置*/
		int locate = -1;
		System.out.println(this.gameJFrame.getPlayersArr());
		for (Player player : gameJFrame.getPlayersArr()) {
			if(player.getSelectedRole().getName().equals("德玛")) {
				locate = player.getSerialNumber();
			}
		}
		
		/*2.技能实现：得到两张牌*/
		Player player = gameJFrame.getPlayersArr().get(locate);
		ArrayList<Card> addCardList = new ArrayList<>();
		
		if(player.getHP().getActualHP() != 0) {
			if (gameJFrame.getCardList().size() < 2) {
				int remain = gameJFrame.getCardList().size();
				for (int i = 0; i < gameJFrame.getCardList().size(); i++) {
					Card addCard = gameJFrame.getCardList().get(i);
					addCard.setCanClick(true);
					addCardList.add(addCard);
				}
				deckUpdate(gameJFrame.getCardList(), gameJFrame.getFoldPile());
				System.out.println("更新完的牌堆的长度为：" + gameJFrame.getCardList().size());
				for (int i = 0; i < 2 - remain; i++) {
					Card addCard = gameJFrame.getCardList().get(i);
					addCard.setCanClick(true);
					addCardList.add(addCard);
				}
				for (int i = 0; i < 2; i++) {
					Card addCard = addCardList.get(i);
					Point to = null;
					if (player.getHandsCard().size() != 0) {
						to = new Point(gameJFrame.playerList.get(0).get(gameJFrame.playerList.get(0).size() - 1).getX() + i * 90, 530);
					} else {
						to = new Point(110, 530);
					}
					Common.move(addCard, addCard.getLocation(),new Point(250 + gameJFrame.playerList.get(0).size() * 90 + i * 90, 530));
					addCard.turnFront();
				}
			} else {
				for (int i = 0; i < 2; i++) {
					Card addCard = gameJFrame.getCardList().get(i);
					addCard.setCanClick(true);
					Point to = null;
					if (player.getHandsCard().size() != 0) {
						to = new Point(gameJFrame.playerList.get(0).get(gameJFrame.playerList.get(0).size() - 1).getX() + (i + 1) * 90, 530);
					} else {
						to = new Point(110, 530);
					}
					Common.moveCard(addCard, to);
					addCard.turnFront();
					addCardList.add(addCard);
				}
			}
			gameJFrame.getCardList().removeAll(addCardList);
			player.getHandsCard().addAll(addCardList);
			/*3.生命减 1*/
			int newHP = player.getHP().getActualHP() - 1;
			player.getHP().setActualHP(newHP);
			player.getHP().rePaintHP();
		}
		
	}
	
	/**牌堆更新 */
	public void deckUpdate(ArrayList<Card> deck, ArrayList<Card> foldPile) {
		// 打乱弃牌堆
		Collections.shuffle(foldPile);
		for (Card card : foldPile) {
			card.setVisible(true);
			card.turnRear();
			card.setCanClick(false);
			card.setClicked(false);
			gameJFrame.getContainer().setComponentZOrder(card, 0);
			Common.moveCard(card, new Point(30, 200));
			deck.add(card);
		}
		foldPile.clear();
	}

}
