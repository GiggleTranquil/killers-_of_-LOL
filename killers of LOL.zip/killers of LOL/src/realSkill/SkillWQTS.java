package realSkill;

import java.awt.Point;

import card.Card;
import game.Common;
import game.GameJFrame;
import player.Player;
import skill.Skill;
import skill.SkillType;

public class SkillWQTS extends Skill{

	static String skillIntroduce = "被伤害时，获得伤害你的那张牌";
	GameJFrame gameJFrame;
	
	public SkillWQTS(GameJFrame gameJFrame) {
		super("无情铁手", SkillType.WHEN_HURT, skillIntroduce);
		this.gameJFrame = gameJFrame;
		// TODO Auto-generated constructor stub
	}
	
	public void effect() {
		/*1.找到诺手所在的位置*/
		int locate = -1;
		System.out.println(this.gameJFrame.getPlayersArr());
		for (Player player : gameJFrame.getPlayersArr()) {
			if(player.getSelectedRole().getName().equals("诺手")) {
				locate = player.getSerialNumber();
			}
		}
		/*2.技能实现：被伤害后，获得伤害我的牌*/
		Player player = gameJFrame.getPlayersArr().get(locate);

		//测试：照着上面的改，看看能不能从弃牌堆里拿牌
		Card getCard = gameJFrame.getFoldPile().get(gameJFrame.getFoldPile().size()-1);
		gameJFrame.getContainer().setComponentZOrder(getCard, 0);
		getCard.setCanClick(true);
		getCard.setClicked(false);
		Point to = null;
		if (player.getHandsCard().size() != 0) {
			to = new Point(player.getHandsCard().get(player.getHandsCard().size() - 1).getX() + 90, 530);
		} else {
			to = new Point(110, 530);
		}
		gameJFrame.getFoldPile().remove(getCard);
		Common.moveCard(getCard, to);
		getCard.turnFront();
		player.getHandsCard().add(getCard);
	}

	

}
