package role;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import card.Card;
import game.GameJFrame;
import player.Player;
import skill.Skill;

public class Role extends JLabel implements MouseListener{
	/**游戏属性*/
	/**角色名*/
	private String name;
	/**技能效果*/
	private Skill skill;
	/**生命上限*/
	private int maximumHP;
	/**测试*/
	public boolean sendShaFlag = false;
	/**GUI*/
	/**判断该角色是否被选择*/
	private boolean isSelected = false;
	/**游戏界面*/
	GameJFrame gameJFrame;


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	public int getMaximumHP() {
		return maximumHP;
	}
	public void setMaximumHP(int maximumHP) {
		this.maximumHP = maximumHP;
	}
	public boolean isSelected() {
		return isSelected;
	}
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
	/**构造方法*/
	public Role(String name, Skill skill, int maximumHP, GameJFrame gameJFrame) {
		super();
		this.name = name;
		this.skill = skill;
		this.maximumHP = maximumHP;
		this.gameJFrame = gameJFrame;
		// 设置角色的宽高
		this.setSize(163, 175);
		// 把角色显示出来
	    this.setVisible(true);
	    // 添加监听
	 	this.addMouseListener(this);
	}
	
	/**显示gui*/
	public void paintRole(){
	}
	
	/*被选择*/
	public void changeIsSelected() {
		this.removeAll();
		JLabel selectedLable = null;
		if(!isSelected) {
			selectedLable = new JLabel(new ImageIcon("src/images/bd_select.png"));
			selectedLable.setBounds(0, 0, 163, 175);
			selectedLable.setVisible(true);
			this.add(selectedLable);
			this.setComponentZOrder(selectedLable, 0);
			//并把其他被选中的角色变成未选中状态
			for(Player player : gameJFrame.getPlayersArr()) {
				if((player.getSelectedRole() != this) && (player.getSelectedRole().isSelected)) {
					player.getSelectedRole().removeAll();
					player.getSelectedRole().repaint();
					player.getSelectedRole().setSelected(false);
				}
			}
		}else {
			selectedLable = new JLabel();
			selectedLable.setBounds(0, 0, 163, 175);
			selectedLable.setVisible(true);
			this.add(selectedLable);
			this.setComponentZOrder(selectedLable, 0);
		}
		this.isSelected = !this.isSelected;
		this.repaint();
	}
	
	/**受伤*/
	public void beHurt() throws InterruptedException {
		JLabel beHurtLable = new JLabel(new ImageIcon("src/images/hurt.png"));
		beHurtLable.setBounds(10,0,163,200);
		beHurtLable.setVisible(true);
		this.add(beHurtLable);
		this.setComponentZOrder(beHurtLable, 0);
		this.repaint();
		Thread.sleep(400);
		this.removeAll();
		this.repaint();
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		boolean flag = false;
		for (Card card : this.gameJFrame.playerList.get(0)) {
			if(card.isClicked()) {
				flag = true;
			}
		}
		/*点击了卡片后，才可选择角色*/
		if(flag) {
			this.changeIsSelected();
		}
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	


}
