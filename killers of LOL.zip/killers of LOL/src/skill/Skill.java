package skill;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;

import game.GameJFrame;

public class Skill extends JButton implements MouseListener{
	/**技能名称*/
	private String name;

	private SkillType type;

	private String introduce;

	GameJFrame gameJFrame;
	public Skill(String name, SkillType type, String introduce) {
		super();
		
		this.name = name;
		this.type = type;
		this.introduce = introduce;
		
		this.setSize(70, 20);
		this.setVisible(true);
		
		if(this.type != SkillType.WHEN_BUTTON_CLICKED) {
			this.setEnabled(false);
		}
		// 添加监听
		this.addMouseListener(this);
	}
	/**技能效果*/
	public void effect() {}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SkillType getType() {
		return type;
	}

	public void setType(SkillType type) {
		this.type = type;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

