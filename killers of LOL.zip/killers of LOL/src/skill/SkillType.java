package skill;

public enum SkillType {
	WHEN_HURT,WHEN_BUTTON_CLICKED,PUSH_THE_LIMITS;

}
